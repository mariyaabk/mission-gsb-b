﻿<?php 
$content = "<h1> Etat Quotidien </h1>
						<table border='1'>
							<tr>
								<td><i><u>Nom</u></i></td>
								<td><i><u>Prenom</u></i></td>
								<td><i><u>num Visiteur</u></i></td>
								<td><i><u>mois fiche</u></i></td>
							</tr>
							<br/>";
							
			foreach($etat as $e){
			$content = $content."<tr>
							<td>".$e['nom']."</td>
							<td>".$e['prenom']."</td>
							<td>".$e['idVisiteur']."</td>
							<td>".$e['mois']."</td>
						</tr>";
			}
			
			$content = $content."
						</table>";
echo $content; 
?>